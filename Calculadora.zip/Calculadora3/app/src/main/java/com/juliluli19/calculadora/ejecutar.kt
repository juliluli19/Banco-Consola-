package com.juliluli19.calculadora


fun main(){
    val cajero = Cajero()
    println("¡Bienvenido al Cajero Automático!")
    print("Ingrese la cantidad de usuarios: ")
    val cantidadUsuarios = readLine()!!.toInt()

    cajero.cargarUsurarios(cantidadUsuarios)

    var option: Int
    do{
        println("\nMENU")
        println("1. Mostrar usuarios")
        println("2. Depositar dinero")
        println("3. Retirar dinero")
        println("4. Salir")
        print("Seleccione el número de la opción: ")
        option = readLine()!!.toInt()

        when(option) {
            1 -> cajero.mostrarUsiarios()
            2 -> cajero.depositar()
            3 -> cajero.retirar()
            4 -> println("Saliendo del cajero. ¡Hasta luego!")
            else -> println("Opción no válida. Por favor, inténtelo de nuevo.")
        }

    }while(option != 4)


}
