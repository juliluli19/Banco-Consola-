package com.juliluli19.calculadora

data class Usuario(var nombre: String , var saldo: Double)

